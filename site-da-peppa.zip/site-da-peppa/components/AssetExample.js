import { Text, View, StyleSheet, Image, Button } from 'react-native';

export default function AssetExample() {
  return (
    <View style={styles.container}>
      <Text style={styles.paragraph}>
       Gostamos de pular na lama
      </Text>
      <Image style={styles.logo} source={require('../assets/jorgee.png')} />

      <Text style={styles.paragraph}>
      </Text>
      <Image style={styles.logo} source={require('../assets/jorge2.jpg')} />
      <Button
      title= 'pule comigo'
      />
    </View>

  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    padding: 24,
  },
  paragraph: {
    margin: 24,
    marginTop: 0,
    fontSize: 14,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  logo: {
    height: 128,
    width: 128,
  }
});
